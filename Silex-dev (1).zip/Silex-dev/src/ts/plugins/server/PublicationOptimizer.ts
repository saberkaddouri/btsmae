
//import { minify } from 'html-minifier'
//const optim = files.map(file => ({
//  ...file,
//  html: minify(file.html, {
//    continueOnParseError: true,
//    collapseInlineTagWhitespace: true,
//    collapseWhitespace: true,
//    minifyCSS: true,
//    minifyJS: true,
//    removeScriptTypeAttributes: true,
//    removeStyleLinkTypeAttributes: true,
//  }).trim(),
//}))
